from fractions import gcd #import the greatest common divisor module

"""
Question Two(2)
"""

#-- A version of N*N
def find_chars_first(string1, string2):
    try:
        assert isinstance(string1, str)
    except:
        return "Invalid argument type, please use a string"
    
    new_arr = [] #list holder for the common characters in string1 and string2
    for i in string1:
        if i in string2: #while looping through 'string1', check if the character exists in 'string2'
            new_arr.append(i)
    return "".join(new_arr)

#-- Print the output to screen
print "Question 2(a) ::"
print find_chars_first('name', 'mame') + "\r\n"
            
#-- A version of N
def find_chars_second(string1, string2): #start of the function
    try:
        assert isinstance(string1, str)
    except:
        return "Invalid argument type, please use a string"
    
    new_str_loop = set(string2);
    return "".join((x for x in new_str_loop if x in new_str_loop))

#-- Print the output to screen
print "Question 2(b) ::"
print find_chars_first('name', 'mame') + "\r\n"

"""
Question Three(3)::
"""

def array_compact_fnc(arr):
    try:
        assert isinstance(arr, list)
    except:
        return "Invalid argument type, please use an array"
        
    if len(arr) < 1:
        return "Please use an array for this test"
    else:
        new_arr = sorted(set(arr))

        print arr #the old list
        print new_arr #the new list

        #return the new array length   
        return "The new size is: %d" % len(new_arr)

#-- Print the output to screen
print "Question Three(3)::"
print array_compact_fnc([1, 3,3,3,3,3,3,6,6,6,6,6,6,6, 7, 7, 8, 9, 9, 9, 10]) + "\r\n"

"""
Question four(4)
"""

def tokenize_string(input_string, delimiter_list = " "):
    #process
    new_str = input_string.split(delimiter_list)
    return new_str

#-- Print the output to screen
print "Question four(4)::"
print tokenize_string("Oh! I so much love what I do")
print "\r\n"

"""
Question Five(5)
"""
def python_array_rotate(arr, n):
    #validate the list argument
    try:
        assert isinstance(arr, list)
    except:
        return "The first argument is wrong, please use an array"

    #validate integer argument
    try:
        assert isinstance(n, int)
    except:
        return "The second argument is wrong, please use an integer"
    
    arr_n_interval = []
    for i in range(n):
        arr_n_interval.append(arr.pop(-1))

    #insert the items of 'arr_n_interval' into 'arr'
    for i in arr_n_interval:
        arr.insert(0, i)

    #return the new list
    return arr

#-- Print the output to screen
n = 4 #number of rotation range
print "Question five(5)::"
print python_array_rotate([1, 2, 3, 4, 5, 6], n)
print "\r\n"

"""
Question six(6)
"""
def get_lcm(arr_list):
    #validate the list argument
    try:
        assert isinstance(arr_list, list)
    except:
        return "The argument is wrong, please use an array"

    #check if any of the index value is not an integer
    definer = 1
    for i in arr_list:
            try:
                assert isinstance(i, int)
            except:
                return "The value " + "'" + i + "'" + " is not an integer"

            definer *= i/gcd(definer, i)

    #return the lcm
    return definer

#-- Print the output to screen
print "Question six(6)::"
print get_lcm([2,4,6,8])    
    
    
